package com.lmgzxh.javase.service;
/*
* 用户业务类
* */
public class UserService {
    /**
     * 登陆方法
     * @param name 用户名
     * @param password 密码
     * @return true表示登陆成功，false表示登陆失败
     */
    public boolean login(String name,String password){
        if("admin".equals(name)&&"123".equals(password)){
            return true;
        }

        return false;
    }

    public void logout(){

        System.out.println("系统已经安全退出");
    }
}
