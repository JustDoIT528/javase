package com.lmgzxh.javase.reflect;

import java.io.FileReader;
import java.util.Properties;

/*
* 验证反射机制的灵活性
*    java代码写一遍，在不改变源码的基础之上，可以做到不同对象的实例化
*   非常灵活（符合OCP原则）
* 包括以后的高级框架，工作中也是用高级框架
*   ssh ssm
*   Spring SpringMVC MyBatis
*   Spring Struts Hibernate
*   ...
*   这些高级框架底层实现原理：都采用了反射机制。所以反射机制还是重要的。
*   学会了反射机制有利于你理解剖析框架底层的源代码
* */
public class ReflectTest03 {
    public static void main(String[] args) throws Exception{
        //通过IO流读取classinfo.properties文件
        FileReader reader = new FileReader("chapter25/classinfo.properties");
        //创建属性类对象Map
        Properties pro = new Properties();
        //加载
        pro.load(reader);
        //关闭流
        reader.close();
        //通过key获取value
        String className = pro.getProperty("className");

        //通过反射机制实例化对象
        Class c = Class.forName(className);
        Object obj = c.newInstance();
        System.out.println(obj);
    }
}
