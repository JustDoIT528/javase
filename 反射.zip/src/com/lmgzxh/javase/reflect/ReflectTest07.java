package com.lmgzxh.javase.reflect;

import java.lang.reflect.Field;

/*
* 掌握：
*   怎么通过反射机制访问一个java对象的属性？
*       给属性赋值set
*       获取属性的值get
* */
public class ReflectTest07 {
    public static void main(String[] args) throws  Exception{

        //使用反射机制，怎么去访问一个对象的属性（get set）
        Class studentClass = Class.forName("com.lmgzxh.javase.bean.Student");
        Object obj = studentClass.newInstance();//obj就是Student对象。（底层调用无参构造）
        //获取no属性。
        Field nofield = studentClass.getDeclaredField("no");
        //给obj对象（Student对象）的no属性赋值
        nofield.set(obj,2222);//给obj对象的no属性赋值2222

        /*
        * 虽然使用了反射机制，但是三要素缺一不可：
        *   要素一：obj对象
        *   要素二：no属性
        *   要素三：2222值
        * 注意：反射机制让代码复杂了，但是为了一个灵活，这也是值得的。
        * */


        //读取属性的值，两个属性：获取obj对象的no属性的值。
        System.out.println(nofield.get(obj));

        //可以访问私有的属性吗
        Field nameField = studentClass.getDeclaredField("name");

        //打破封装(反射机制的缺点：打破封装，可能会给不法分子留下机会)
        //这样设置完之后，在外部也是可以访问private的
        nameField.setAccessible(true);
        //给name属性赋值
        nameField.set(obj,"周小花");
        System.out.println(nameField.get(obj));
    }
}
