package com.lmgzxh.javase.reflect;

import java.util.ResourceBundle;

/*
*java.util下提供了资源绑定器，便于获取属性配置文件中的内容
*使用以下这种方式的时候，属性配置文件***.properties必须放到类路径下（以src为起点）
* */
public class ResourceBundleTest {
    public static void main(String[] args) {
        //资源绑定器，只能绑定***.properties文件，并且这个文件必须在类路径下
        //文件拓展名也必须是properties
        //ResourceBundle bundle = ResourceBundle.getBundle("classinfo2");
        ResourceBundle bundle = ResourceBundle.getBundle("com/lmgzxh/javase/bean/db");
        String className=bundle.getString("className");
        System.out.println(className);
    }
}
