package com.lmgzxh.javase.reflect;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/*
* 通过反射机制，反编译一个类的属性Field
* */
public class ReflectTest06 {
    public static void main(String[] args) throws Exception{
        //创建这个是为了拼接字符串
        StringBuilder s = new StringBuilder();

        Class studentClass = Class.forName("java.lang.String");

        s.append(Modifier.toString(studentClass.getModifiers())+" class "+studentClass.getSimpleName()+"{\n");
        Field[] fields = studentClass.getDeclaredFields();

        for (Field fi:fields
             ) {
            s.append("\t");
            s.append(Modifier.toString(fi.getModifiers()));
            s.append(" ");
            s.append(fi.getType().getSimpleName());
            s.append(" ");
            s.append(fi.getName());
            s.append(";\n");
        }

        s.append("}");

        System.out.println(s);
    }
}
