package com.lmgzxh.javase.reflect;

import java.lang.reflect.Method;

/*
*重点：必须掌握，通过反射机制怎么调用一个对象的方法？
*   ******掌握
*   反射机制，让代码很具有通用性，可变化的内容都是写到配置文件当中
*   将来修改配置文件，不需要修改java代码。
* */
public class ReflectTest10 {
    public static void main(String[] args) throws Exception{
        //使用反射机制获取类名
        Class userServiceClass = Class.forName("com.lmgzxh.javase.service.UserService");
        //创建对象
        Object obj = userServiceClass.newInstance();
        //获取Method
        Method loginmethod= userServiceClass
                .getDeclaredMethod("login", String.class, String.class);
        //调用方法
        //调用方发有几个要素？
        /*
        * 1、对象
        * 2、login方法名
        * 3、实参列表
        * 4、返回值
        * */
        //反射机制中最最最重要的一个方法。
        Object retValue = loginmethod.invoke(obj,"admin","123");
        System.out.println(retValue);
    }
}
