package com.lmgzxh.javase.reflect;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/*
*反射Student类中所有的Field
*
* */
public class RefletcTest05 {
    public static void main(String[] args) throws Exception{
        //获取整个类
        Class studentClass = Class.forName("com.lmgzxh.javase.bean.Student");
        System.out.println(studentClass.getName());//完整类名
        System.out.println(studentClass.getSimpleName());//简类名

        //获取类中所有的Field
        Field[] fileds=studentClass.getFields();

        System.out.println(fileds.length);//1,测试数组中只有一个元素
        //取出这个fileds
        Field f = fileds[0];
        //取出这个Field它的名字
        String fieldName = f.getName();

        System.out.println(fieldName);

        //获取所有的Field
        Field[] fs = studentClass.getDeclaredFields();
        System.out.println(fs.length);//4
        System.out.println("=======================");
        for (Field fi:fs
             ) {
            //获取属性的修饰符列表
            int i = fi.getModifiers();//返回的修饰符是一个数字，每个数字是修饰符的代号。
            //可以将数字转换为字符串吗
            String s = Modifier.toString(i);
            System.out.println(s);
            //获取属性的类型
            Class fieldType = fi.getType();
            System.out.println(fieldType.getName());

            //获取属性的名字
            System.out.println(fi.getName());
        }

    }
}
