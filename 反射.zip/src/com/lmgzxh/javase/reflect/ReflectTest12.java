package com.lmgzxh.javase.reflect;
import java.lang.reflect.Constructor;
/*
* 重要一些
* */
public class ReflectTest12 {
    public static void main(String[] args) throws Exception{
        //使用反射机制创建对象
        Class c = Class.forName("com.lmgzxh.javase.bean.Vip");
        //调用无参构造方法
        Object obj = c.newInstance();
        System.out.println(obj);
        //调用有参数的构造方法怎么办？
        //第一步：先获取到这个有参数的构造方法
        Constructor con = c.getDeclaredConstructor(int.class,String.class);
        //第二步：调用构造方法new对象
        Object newobj = con.newInstance(110,"周小花");
        System.out.println(newobj);

        Constructor con2 = c.getDeclaredConstructor();
        Object obj2 = con2.newInstance();
        System.out.println(obj2);
    }
}
