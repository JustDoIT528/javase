package com.lmgzxh.javase.reflect;
/*
* 可变长度参数
*   int...args这就是int类型可变长度参数
*   语法是：类型...(注意：一定是3个点)
*   1、可变长度参数要求的参数个数是：0-N个
*   2、可变长度参数在参数列表中必须在最后一个位置上，而且可变长度参数只能有一个。
*   3、可变长度参数可以当作一个数组来看待
* */
public class ArgsTest {
    public static void main(String[] args) {
        m(1,2,3,43,4);

        m3(2,"dasd","dsadas");//可以
        //m4("周小花","李棒槌","周胖花");
        String[] strs = {"周小花","李棒槌","周胖花","周大花"};
        //m4(strs);//也可以传一个数组
        m4(new String[]{"我","是","周","小","花"});
    }
    public static void m(int...args){
        System.out.println("m方法执行了");
    }
   /* public static void m2(String...args2,int...args){


    }*/
    public static void m3(int a,String...args2){


    }
    public static void m4(String...args){
        //args有length属性，说明args是一个数组
        for (int i = 0; i < args.length; i++) {
            System.out.println(args[i]);
        }
    }
}
