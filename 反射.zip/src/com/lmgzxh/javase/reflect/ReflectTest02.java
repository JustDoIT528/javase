package com.lmgzxh.javase.reflect;
/*
*获取到Class，能干什么？
*       通过Class的newInstance()方法来实例化对象，
*       注意：newInstance()方法内部实际上调用了无参构造方法，必须保证无参构造的存在才可以
* */
public class ReflectTest02 {
    public static void main(String[] args) {

        try {
            //通过反射机制，获取Class,通过Class来实例化对象
            Class c = Class.forName("com.lmgzxh.javase.bean.User");//c代表User类型
            //newInstance()会调用类的无参数构造方法，完成对象的创建
            //如果没有写无参构造方法，java.lang.InstantiationException
            //重点是newInstance()调用得是无参构造，必须保证无参构造是存在的。
            Object obj = c.newInstance();
            System.out.println(obj);

        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
        }

    }
}
